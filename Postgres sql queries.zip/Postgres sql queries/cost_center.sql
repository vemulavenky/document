INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('000', 'Policies');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('001', 'Product Engineering Services (PES)');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('002', 'Product Engineering (PE)');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('003', 'Industrially Automation Services (IAS)');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('004', 'Industrially Automation (IA)');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('005', 'Digital Business (DB)');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('006', 'Biometrics Technology (BT)');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('007', 'Support System');
INSERT INTO cost_center (cost_center_code, cost_center) VALUES ('008', 'Process Quality Assurance (PQA)');
