INSERT INTO document_type (document_type_code, document_type) VALUES
('01', 'Policy'),
('02', 'Pre-sales'),
('03', 'Process Quality Assurance'),
('04', 'Process Management'),
('05', 'Process Asset Development'),
('06', 'Requirement Development & Management'),
('07', 'Decision Analysis & Resolution'),
('08', 'Estimating');